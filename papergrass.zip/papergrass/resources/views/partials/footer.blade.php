<footer class="footer">
      <p class="copyright">©2016 All Rights Reserved. <a href="http://elevenelevencreative.com" target="_blank">Site by: Josua Simanungkalit</a></p>
</footer>