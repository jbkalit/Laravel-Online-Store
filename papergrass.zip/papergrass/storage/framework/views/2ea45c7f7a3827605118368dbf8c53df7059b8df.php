<?php $__env->startSection('title'); ?>
    Papergrass Online Store
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <div class="row">
            <div class="col-sm-6 col-md-4 col-md-offset-4 col-sm-offset-3">
                <div id="charge-message" class  ="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <h2>Produk</h2>
    <img class="batas" src="http://imageshack.com/a/img921/1685/c9hajn.png">
    <div class="row">
        <div class="col-md-5 col-sm-2"> 
        <img src="<?php echo e($product->imagePath); ?>" alt="..." class="img-responsive">
        </div>
        <div class="col-md-7 col-sm-2">
            <div class="thumbnail">
                <div class="caption">
                <h3><?php echo e($product->title); ?></h3>
                <p class="description"><?php echo e($product->
                description); ?></p>
                <div class="clearfix">
                <div class="pull-left price">Rp <?php echo e($product->price); ?></div>
                <a href="<?php echo e(route('product.addToCart', ['id' => $product->id])); ?>" class="btn btn-success pull-right" role="button ">Tambah</a>
                </div>
                
                </div>
            </div>
        </div>
        
    </div>
    <img class="batas" src="http://imageshack.com/a/img921/1685/c9hajn.png">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>