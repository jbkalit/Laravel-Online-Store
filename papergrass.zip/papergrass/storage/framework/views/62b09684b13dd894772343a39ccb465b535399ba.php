<?php $__env->startSection('content'); ?>
 <h1>User Profile</h1>
 <img class="batas" src="http://imageshack.com/a/img921/1685/c9hajn.png">
	<div class="row">
        <div class="col-md-8 col-md-offset-2">
           
            <h2>My Orders</h2>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="panel panel-default">
                    <div class="panel-body">
                        <ul class="list-group">
                            <?php $__currentLoopData = $order->cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li class="list-group-item">
                                    <span class="badge">Rp <?php echo e($item['price']); ?></span>
                                    <?php echo e($item['item']['title']); ?> | <?php echo e($item['qty']); ?> Units
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </ul>
                    </div>
                    <div class="panel-footer">
                        <strong>Total Price: Rp <?php echo e($order->cart->totalPrice); ?></strong>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
</div>
 <img class="batas" src="http://imageshack.com/a/img921/1685/c9hajn.png">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>