<!doctype <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	
	<title><?php echo $__env->yieldContent('title'); ?></title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?php echo e(URL::to('css/app.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(URL::to('css/header.css')); ?>">

	<?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
	<?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
	</div>

	<script
	src="https://code.jquery.com/jquery-1.12.4.min.js"
	integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ="
	crossorigin="anonymous"></script>

	<script 
	src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" 
	integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" 
	crossorigin="anonymous"></script>



	<?php echo $__env->yieldContent('scripts'); ?>

	<footer>Created By Papergrass</footer>

</body>
</html>