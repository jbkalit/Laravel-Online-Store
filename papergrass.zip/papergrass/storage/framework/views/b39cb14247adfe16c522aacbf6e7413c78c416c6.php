<?php $__env->startSection('title'); ?>
    Papergrass Online Store
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <div class="row">
            <div class="col-sm-6 col-md-4 col-md-offset-4 col-sm-offset-3">
                <div id="charge-message" class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <section class="hero">
     <div class="logo"><img src="http://imageshack.com/a/img922/2651/w0Ziba.png"></div>
    </section>

    <img class="batas" src="http://imageshack.com/a/img921/1685/c9hajn.png">

    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-md-3 col-sm-6">
            <div class="thumbnail">
                

                <a href="<?php echo e(route('product.show', ['id' => $value->id])); ?>"><img src="<?php echo e($value->imagePath); ?>" alt="..." class="img-responsive"></a>
                <h4><?php echo e($value->title); ?></h4>
               
            </div>
        </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>     
    </div>


     <img class="batas" src="http://imageshack.com/a/img921/1685/c9hajn.png">

     
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>